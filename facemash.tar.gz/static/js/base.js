$(function() {
    $("#img-A").click(function() {
        $("#A").submit();
    })
    $("#img-B").click(function() {
        $("#B").submit();
    })
});
